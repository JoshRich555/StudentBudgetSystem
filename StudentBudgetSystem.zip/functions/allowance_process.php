<?php

include('../Connection/database.php');

if(isset($_POST['add_allowance'])){

    session_start();

    $user_id = $_SESSION['user']['id'];
    $amount = $_POST['amount'];
    $date = $_POST['allowance_date'];

    mysqli_query(
        $conn,
        "INSERT INTO allowances
        (user_id,amount,allowance_date)
        VALUES
        ('$user_id','$amount','$date')"
    );

    header("Location: ../Views/allowance.php");
    exit();
}
?>