<?php

include('../Connection/database.php');

$message = '';

if(isset($_POST['register'])){

    $username = mysqli_real_escape_string(
        $conn,
        $_POST['username']
    );

    $email = mysqli_real_escape_string(
        $conn,
        $_POST['email']
    );

    $password = password_hash(
        $_POST['password'],
        PASSWORD_DEFAULT
    );

    $check = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email'"
    );

    if(mysqli_num_rows($check) > 0){

        $message = "Email already exists";

    }else{

        mysqli_query(
            $conn,
            "INSERT INTO users(username,email,password)
             VALUES('$username','$email','$password')"
        );

        header("Location: ../Views/login.php");
        exit();
    }
}
?>