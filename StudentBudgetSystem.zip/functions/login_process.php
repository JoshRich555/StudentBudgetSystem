<?php

session_start();
include('../Connection/database.php');

$error = '';

if(isset($_POST['login'])){

    $email = mysqli_real_escape_string(
        $conn,
        $_POST['email']
    );

    $password = $_POST['password'];

    $query = mysqli_query(
        $conn,
        "SELECT * FROM users WHERE email='$email'"
    );

    if(mysqli_num_rows($query) > 0){

        $user = mysqli_fetch_assoc($query);

        if(password_verify(
            $password,
            $user['password']
        )){

            $_SESSION['user'] = $user;

            header("Location: ../Views/dashboard.php");
            exit();

        }else{

            $error = "Invalid Password";
        }

    }else{

        $error = "User Not Found";
    }
}
?>