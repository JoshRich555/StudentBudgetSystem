<?php

include('../Connection/database.php');

if(isset($_POST['add_goal'])){

    session_start();

    $user_id = $_SESSION['user']['id'];

    $goal_name = $_POST['goal_name'];

    $target_amount = $_POST['target_amount'];

    mysqli_query(
        $conn,
        "INSERT INTO savings_goals
        (
        user_id,
        goal_name,
        target_amount
        )
        VALUES
        (
        '$user_id',
        '$goal_name',
        '$target_amount'
        )"
    );

    header("Location: ../Views/savings.php");
    exit();
}
?>