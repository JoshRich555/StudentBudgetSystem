<?php

include('../Connection/database.php');

if(isset($_POST['add_expense'])){

    session_start();

    $user_id = $_SESSION['user']['id'];

    $category = $_POST['category'];

    $description = $_POST['description'];

    $amount = $_POST['amount'];

    $date = $_POST['expense_date'];

    mysqli_query(
        $conn,
        "INSERT INTO expenses
        (
        user_id,
        category,
        description,
        amount,
        expense_date
        )
        VALUES
        (
        '$user_id',
        '$category',
        '$description',
        '$amount',
        '$date'
        )"
    );

    header("Location: ../Views/expenses.php");
    exit();
}
?>