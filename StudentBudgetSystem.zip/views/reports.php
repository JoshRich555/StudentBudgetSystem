<?php

include('../Functions/auth_check.php');
include('../Connection/database.php');

$user_id = $_SESSION['user']['id'];

$result = mysqli_query(
$conn,
"SELECT category,
SUM(amount) AS total
FROM expenses
WHERE user_id='$user_id'
GROUP BY category"
);
?>

<!DOCTYPE html>
<html>
<head>

<title>Expense Reports</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<h2>Expense Report</h2>

<table class="table table-bordered">

<tr>
<th>Category</th>
<th>Total Expenses</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td><?php echo $row['category']; ?></td>

<td>
₱<?php echo number_format($row['total'],2); ?>
</td>

</tr>

<?php } ?>

</table>

<a href="dashboard.php"
class="btn btn-secondary">
Back
</a>

</div>

</body>
</html>