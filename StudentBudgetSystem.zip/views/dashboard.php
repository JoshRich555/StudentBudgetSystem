<?php

include('../Functions/auth_check.php');
include('../Connection/database.php');

$userId = $_SESSION['user']['id'];

$totalAllowance = mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT IFNULL(SUM(amount),0) total
FROM allowances
WHERE user_id='$userId'"
));

$totalExpense = mysqli_fetch_assoc(
mysqli_query(
$conn,
"SELECT IFNULL(SUM(amount),0) total
FROM expenses
WHERE user_id='$userId'"
));

$remaining =
$totalAllowance['total']
-
$totalExpense['total'];

?>

<!DOCTYPE html>
<html>
<head>

<title>Dashboard</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<h2>
Welcome,
<?php echo $_SESSION['user']['username']; ?>
</h2>

<div class="row mt-4">

<div class="col-md-4">

<div class="card p-3">

<h4>Total Allowance</h4>

<h2>
₱<?php echo $totalAllowance['total']; ?>
</h2>

</div>

</div>

<div class="col-md-4">

<div class="card p-3">

<h4>Total Expenses</h4>

<h2>
₱<?php echo $totalExpense['total']; ?>
</h2>

</div>

</div>

<div class="col-md-4">

<div class="card p-3">

<h4>Remaining Balance</h4>

<h2>
₱<?php echo $remaining; ?>
</h2>

</div>

</div>

</div>

<a href="allowance.php"
class="btn btn-primary mt-4">
Manage Allowance
</a>

<a href="expenses.php"
class="btn btn-success mt-4">
Manage Expenses
</a>

<a href="savings.php"
class="btn btn-warning mt-4">
Savings Goals
</a>

</div>

</body>
</html>