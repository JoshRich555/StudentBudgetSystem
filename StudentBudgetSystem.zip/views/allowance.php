<?php

include('../Functions/auth_check.php');
include('../Connection/database.php');

$user_id = $_SESSION['user']['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM allowances
WHERE user_id='$user_id'
ORDER BY allowance_date DESC"
);
?>

<!DOCTYPE html>
<html>
<head>

<title>Allowance</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<h2>Add Allowance</h2>

<form method="POST"
action="../Functions/allowance_process.php">

<input type="number"
step="0.01"
name="amount"
class="form-control mb-3"
placeholder="Allowance Amount"
required>

<input type="date"
name="allowance_date"
class="form-control mb-3"
required>

<button type="submit"
name="add_allowance"
class="btn btn-primary">
Save Allowance
</button>

</form>

<hr>

<h3>Allowance History</h3>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Amount</th>
<th>Date</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td>
₱<?php echo $row['amount']; ?>
</td>

<td>
<?php echo $row['allowance_date']; ?>
</td>

</tr>

<?php } ?>

</table>

<a href="dashboard.php"
class="btn btn-secondary">
Back
</a>

</div>

</body>
</html>