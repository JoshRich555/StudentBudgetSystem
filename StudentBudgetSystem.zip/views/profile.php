<?php

include('../Functions/auth_check.php');

$user = $_SESSION['user'];

?>

<!DOCTYPE html>
<html>
<head>

<title>Profile</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<div class="card p-4">

<h2>Student Profile</h2>

<hr>

<h5>
Username:
<?php echo $user['username']; ?>
</h5>

<h5>
Email:
<?php echo $user['email']; ?>
</h5>

<a href="../Functions/logout.php"
class="btn btn-danger mt-3">
Logout
</a>

</div>

</div>

</body>
</html>