<?php

include('../Functions/auth_check.php');
include('../Connection/database.php');

$user_id = $_SESSION['user']['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM savings_goals
WHERE user_id='$user_id'"
);
?>

<!DOCTYPE html>
<html>
<head>

<title>Savings Goals</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<h2>Savings Goals</h2>

<form method="POST"
action="../Functions/savings_process.php">

<input type="text"
name="goal_name"
class="form-control mb-3"
placeholder="Goal Name"
required>

<input type="number"
step="0.01"
name="target_amount"
class="form-control mb-3"
placeholder="Target Amount"
required>

<button type="submit"
name="add_goal"
class="btn btn-warning">
Add Goal
</button>

</form>

<hr>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Goal</th>
<th>Target Amount</th>
<th>Current Amount</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['goal_name']; ?></td>

<td>₱<?php echo $row['target_amount']; ?></td>

<td>₱<?php echo $row['current_amount']; ?></td>

</tr>

<?php } ?>

</table>

<a href="dashboard.php"
class="btn btn-secondary">
Back
</a>

</div>

</body>
</html>