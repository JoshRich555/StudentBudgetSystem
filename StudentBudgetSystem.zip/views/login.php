<?php
include('../Functions/login_process.php');
?>

<!DOCTYPE html>
<html>
<head>

<title>Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<link rel="stylesheet"
href="../Assets/css/style.css">

</head>
<body>

<div class="container mt-5">

<div class="card p-4 login-card">

<h2 class="text-center mb-4">
Student Budget System
</h2>

<?php if($error!=''){ ?>

<div class="alert alert-danger">
<?php echo $error; ?>
</div>

<?php } ?>

<form method="POST">

<input type="email"
name="email"
class="form-control mb-3"
placeholder="Email"
required>

<input type="password"
name="password"
class="form-control mb-3"
placeholder="Password"
required>

<button type="submit"
name="login"
class="btn btn-success w-100">
Login
</button>

</form>

<a href="register.php"
class="mt-3 d-block text-center">
Create Account
</a>

</div>

</div>

</body>
</html>