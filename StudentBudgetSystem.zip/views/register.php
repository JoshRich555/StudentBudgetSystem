<?php
include('../Functions/register_process.php');
?>

<!DOCTYPE html>
<html>
<head>

<title>Register</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<div class="card p-4">

<h2 class="text-center">
Register
</h2>

<form method="POST">

<input type="text"
name="username"
class="form-control mb-3"
placeholder="Username"
required>

<input type="email"
name="email"
class="form-control mb-3"
placeholder="Email"
required>

<input type="password"
name="password"
class="form-control mb-3"
placeholder="Password"
required>

<button type="submit"
name="register"
class="btn btn-primary w-100">
Register
</button>

</form>

</div>

</div>

</body>
</html>