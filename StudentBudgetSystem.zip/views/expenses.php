<?php

include('../Functions/auth_check.php');
include('../Connection/database.php');

$user_id = $_SESSION['user']['id'];

$result = mysqli_query(
$conn,
"SELECT * FROM expenses
WHERE user_id='$user_id'
ORDER BY expense_date DESC"
);
?>

<!DOCTYPE html>
<html>
<head>

<title>Expenses</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<div class="container mt-5">

<h2>Add Expense</h2>

<form method="POST"
action="../Functions/expense_process.php">

<select
name="category"
class="form-control mb-3"
required>

<option value="">
Select Category
</option>

<option>Transportation</option>
<option>Meals</option>
<option>School Materials</option>
<option>Rental Fees</option>
<option>Water Bill</option>
<option>Electricity Bill</option>
<option>Internet</option>
<option>Tuition</option>
<option>Others</option>

</select>

<input type="text"
name="description"
class="form-control mb-3"
placeholder="Description"
required>

<input type="number"
step="0.01"
name="amount"
class="form-control mb-3"
placeholder="Amount"
required>

<input type="date"
name="expense_date"
class="form-control mb-3"
required>

<button type="submit"
name="add_expense"
class="btn btn-success">
Save Expense
</button>

</form>

<hr>

<h3>Expense History</h3>

<table class="table table-bordered">

<tr>
<th>ID</th>
<th>Category</th>
<th>Description</th>
<th>Amount</th>
<th>Date</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td><?php echo $row['id']; ?></td>

<td><?php echo $row['category']; ?></td>

<td><?php echo $row['description']; ?></td>

<td>
₱<?php echo $row['amount']; ?>
</td>

<td>
<?php echo $row['expense_date']; ?>
</td>

</tr>

<?php } ?>

</table>

<a href="dashboard.php"
class="btn btn-secondary">
Back
</a>

</div>

</body>
</html>